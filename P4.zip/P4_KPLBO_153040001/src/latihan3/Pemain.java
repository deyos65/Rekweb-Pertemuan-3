package latihan3;

import java.util.Iterator;

public class Pemain {
	private String nama;
	private int noPunggung;
	private int gaji;
	
	
	public Pemain() {
		this("");//untuk mencari knstruktor yang parameter 1
		
	}
	
	public Pemain(String nama) {
		this(nama,0);//untuk mencari knstruktor yang parameter 2
		
	}//0 dikasin nilai defaut
	
	public Pemain(String nama, int noPunggung) {
		this(nama, noPunggung,0); //untuk mencari knstruktor yang parameter 3
		
	}
	
	public Pemain(String nama,int noPunggung, int gaji){
		this.nama= nama;
		this.noPunggung = noPunggung;
		this.gaji=gaji;
	}
	
	public void setNama(String nama) {
		this.nama= nama;
	}
	
	public String getnama() {
		return nama;
		
	}
	
	public void setNoPunggung(int noPunggung) {
		this.noPunggung= noPunggung;
	}
	public int getnoPunggung() {
		return noPunggung;
	}
	
	public void setGaji(int gaji) {
		this.gaji=gaji;
		
	}
	public int getGaji() {
		return gaji;
	}
	
	public int hitungGajiPerbulan() {
		return gaji= 4;
	}

	
	public String toString() {
		return noPunggung+","+nama+"\ngaji Per minggu :"+gaji+
									"\n gaji per bulan: "+hitungGajiPerbulan()+
									"\n";
		}
	}

