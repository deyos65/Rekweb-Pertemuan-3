package latihan2;

public class Tim {
		private String nama;
		
		public Tim () {
			nama = "";
			
		}
		
		public Tim (String nama) {
			this.nama = nama;
		}
		//set get
		public String getNama() {
			return nama;
		}

		public void setNama(String nama) {
			this.nama = nama;
		}
}
